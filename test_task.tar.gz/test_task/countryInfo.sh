#!/bin/bash

/etc/init.d/postgresql start;
sleep 40;

echo "Hello $(whoami)"
if [ "$(whoami)" = 'root' ] || [ "$(whoami)" = 'postgres' ]; then
        read "Please enter value for iso3:" >>  $input;
        if [ $input = '' ]; then
                psql application -c 'select id as num, nicename, iso3 as iso, numcode, phonecode from country'
        else
                psql application -c "select id as num, nicename, iso3 as iso, numcode, phonecode from country where iso3 = '$input'"
        fi
else
        echo "Plesae be root or postgres to run this script correctly"
fi

